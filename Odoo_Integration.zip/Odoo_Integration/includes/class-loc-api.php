<?php
/**
 * LOC_API — Odoo HTTP API client.
 *
 * Default: **JSON-2** (`POST /json/2/<model>/<method>`, `Authorization: bearer <api-key>`),
 * required for typical Odoo 19+ setups where `/web/dataset/call_kw` rejects external POST (405).
 *
 * Optional: **JSON-RPC** (`POST /jsonrpc`, `common` + `object.execute_kw`) for self-hosted
 * Odoo 14–18. Choose in settings or set `LOC_ODOO_API_MODE` to `jsonrpc` in wp-config.php.
 *
 * Credentials: `LOC_ODOO_URL`, `LOC_ODOO_DB`, `LOC_ODOO_PASSWORD` (API key for JSON-2).
 * JSON-RPC mode also needs `LOC_ODOO_USER` + password/API key.
 *
 * Writes: `create` / `write` / `call` are blocked when `loc_odoo_writes_allowed` is false (default).
 * Product catalog models (`product.template`, `product.product`) are always blocked unless
 * `loc_odoo_allow_product_catalog_write` is true — prevents accidental Internal Reference corruption.
 *
 * @package LIMO_Odoo_Connector
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class LOC_API {

    /** Cached uid from JSON-2 context_get or JSON-RPC authenticate. */
    private static ?int $uid = null;

    /** Log at most one api_write line per HTTP request (avoid spam). */
    private static bool $logged_api_write_block = false;

    /**
     * Global switch for any Odoo mutation (create, write, call).
     * Default false. Enable: `define( 'LOC_ODOO_WRITES_ALLOWED', true );` or filter `loc_odoo_writes_allowed`.
     */
    public static function writes_allowed(): bool {
        if ( defined( 'LOC_ODOO_WRITES_ALLOWED' ) ) {
            return (bool) LOC_ODOO_WRITES_ALLOWED;
        }
        return (bool) apply_filters( 'loc_odoo_writes_allowed', false );
    }

    /**
     * Block writes to product master data even when `writes_allowed()` is true (e.g. order sync).
     */
    public static function catalog_model_write_forbidden( string $model ): bool {
        if ( apply_filters( 'loc_odoo_allow_product_catalog_write', false ) ) {
            return false;
        }
        $blocked = apply_filters(
            'loc_odoo_blocked_catalog_models',
            [ 'product.template', 'product.product' ]
        );
        return in_array( $model, $blocked, true );
    }

    private static function log_api_write_blocked_once( string $message ): void {
        if ( self::$logged_api_write_block ) {
            return;
        }
        self::$logged_api_write_block = true;
        self::log( 'api_write', 0, 0, 'ok', $message );
    }

    /**
     * Clear cached JSON-RPC uid and per-request API write log flag (e.g. before “Test connection”).
     */
    public static function reset_auth(): void {
        self::$uid                     = null;
        self::$logged_api_write_block = false;
    }

    public static function url(): string {
        return defined( 'LOC_ODOO_URL' )
            ? rtrim( LOC_ODOO_URL, '/' )
            : rtrim( (string) get_option( 'loc_odoo_url', '' ), '/' );
    }

    public static function db(): string {
        return defined( 'LOC_ODOO_DB' )
            ? LOC_ODOO_DB
            : (string) get_option( 'loc_odoo_db', '' );
    }

    public static function user(): string {
        return defined( 'LOC_ODOO_USER' )
            ? LOC_ODOO_USER
            : (string) get_option( 'loc_odoo_user', '' );
    }

    /** API key (JSON-2) or password (JSON-RPC). */
    public static function password(): string {
        return defined( 'LOC_ODOO_PASSWORD' )
            ? LOC_ODOO_PASSWORD
            : (string) get_option( 'loc_odoo_password', '' );
    }

    /**
     * `json2` (default) or `jsonrpc`.
     */
    public static function api_mode(): string {
        if ( defined( 'LOC_ODOO_API_MODE' ) && in_array( LOC_ODOO_API_MODE, [ 'json2', 'jsonrpc' ], true ) ) {
            return LOC_ODOO_API_MODE;
        }
        $m = (string) get_option( 'loc_odoo_api_mode', 'json2' );
        return in_array( $m, [ 'json2', 'jsonrpc' ], true ) ? $m : 'json2';
    }

    /**
     * Verify credentials; cache uid when possible.
     *
     * @return int|false Odoo user id or false on failure.
     */
    public static function authenticate(): int|false {
        if ( self::$uid !== null ) {
            return self::$uid;
        }

        if ( self::api_mode() === 'jsonrpc' ) {
            $result = self::legacy_jsonrpc(
                self::url() . '/jsonrpc',
                'common',
                'authenticate',
                [ self::db(), self::user(), self::password(), [] ]
            );
            if ( is_int( $result ) && $result > 0 ) {
                self::$uid = $result;
                return self::$uid;
            }
            self::log( 'auth', 0, 0, 'error', 'JSON-RPC authenticate failed: ' . wp_json_encode( $result ) );
            return false;
        }

        $ctx = self::json2_request( 'res.users', 'context_get', [] );
        if ( is_array( $ctx ) && ! empty( $ctx['uid'] ) ) {
            self::$uid = (int) $ctx['uid'];
            return self::$uid;
        }

        self::log( 'auth', 0, 0, 'error', 'JSON-2 context_get failed (check API key & database name).' );
        return false;
    }

    public static function search( string $model, array $domain = [], array $kwargs = [] ): array|false {
        if ( self::api_mode() === 'jsonrpc' ) {
            $r = self::legacy_execute( $model, 'search', [ $domain ], $kwargs );
            return self::normalize_id_list_result( $r );
        }
        $body = array_merge( [ 'domain' => $domain ], $kwargs );
        $r    = self::json2_request( $model, 'search', $body );
        return self::normalize_id_list_result( $r );
    }

    public static function search_read( string $model, array $domain = [], array $fields = [], array $kwargs = [] ): array|false {
        $kwargs['fields'] = $fields;
        if ( self::api_mode() === 'jsonrpc' ) {
            $r = self::legacy_execute( $model, 'search_read', [ $domain ], $kwargs );
            return self::normalize_search_read_rows( $r );
        }
        $kwargs['domain'] = $domain;
        $r                = self::json2_request( $model, 'search_read', $kwargs );
        return self::normalize_search_read_rows( $r );
    }

    public static function read( string $model, array $ids, array $fields = [] ): array|false {
        if ( $ids === [] ) {
            return [];
        }
        if ( self::api_mode() === 'jsonrpc' ) {
            $r = self::legacy_execute( $model, 'read', [ $ids, $fields ], [] );
            return self::normalize_search_read_rows( $r );
        }
        $r = self::json2_request( $model, 'read', [ 'ids' => array_values( $ids ), 'fields' => $fields ] );
        return self::normalize_search_read_rows( $r );
    }

    public static function create( string $model, array $vals ): int|false {
        if ( ! self::writes_allowed() ) {
            self::log_api_write_blocked_once( 'Odoo writes disabled (LOC_ODOO_WRITES_ALLOWED / loc_odoo_writes_allowed).' );
            return false;
        }
        if ( self::catalog_model_write_forbidden( $model ) ) {
            self::log_api_write_blocked_once( 'Blocked create on catalog model ' . $model . ' (loc_odoo_allow_product_catalog_write).' );
            return false;
        }
        if ( self::api_mode() === 'jsonrpc' ) {
            $r = self::legacy_execute( $model, 'create', [ $vals ], [] );
            return self::normalize_create_result( $r );
        }
        $r = self::json2_request( $model, 'create', [ 'vals_list' => [ $vals ] ] );
        return self::normalize_create_result( $r );
    }

    public static function write( string $model, array $ids, array $vals ): bool {
        if ( ! self::writes_allowed() ) {
            self::log_api_write_blocked_once( 'Odoo writes disabled (LOC_ODOO_WRITES_ALLOWED / loc_odoo_writes_allowed).' );
            return false;
        }
        if ( self::catalog_model_write_forbidden( $model ) ) {
            self::log_api_write_blocked_once( 'Blocked write on catalog model ' . $model . ' (loc_odoo_allow_product_catalog_write).' );
            return false;
        }
        if ( self::api_mode() === 'jsonrpc' ) {
            $r = self::legacy_execute( $model, 'write', [ $ids, $vals ], [] );
            return $r === true;
        }
        $r = self::json2_request( $model, 'write', [ 'ids' => $ids, 'vals' => $vals ] );
        return $r === true;
    }

    public static function call( string $model, string $method, array $args = [], array $kwargs = [] ): mixed {
        if ( ! self::writes_allowed() ) {
            self::log_api_write_blocked_once( 'Odoo writes disabled (LOC_ODOO_WRITES_ALLOWED / loc_odoo_writes_allowed).' );
            return false;
        }
        if ( self::catalog_model_write_forbidden( $model ) ) {
            self::log_api_write_blocked_once( 'Blocked call on catalog model ' . $model . '.' . $method . ' (loc_odoo_allow_product_catalog_write).' );
            return false;
        }
        if ( self::api_mode() === 'jsonrpc' ) {
            return self::legacy_execute( $model, $method, $args, $kwargs );
        }
        $body = $kwargs;
        if ( $args !== [] && isset( $args[0] ) && is_array( $args[0] ) ) {
            $body['ids'] = $args[0];
        }
        return self::json2_request( $model, $method, $body );
    }

    /**
     * Sum qty_available on product.product variants per product.template id.
     *
     * Odoo 17+ / 19+ often reject qty_available on product.template (HTTP 500 / invalid field).
     * Stock lives on variants; multi-variant templates get summed qty.
     *
     * @param int[] $template_ids product.template database ids.
     * @return array<int,float> template_id => total qty_available
     */
    public static function sum_qty_available_by_template_ids( array $template_ids ): array {
        $ids = [];
        foreach ( $template_ids as $id ) {
            $i = (int) $id;
            if ( $i > 0 ) {
                $ids[] = $i;
            }
        }
        $ids = array_values( array_unique( $ids, SORT_NUMERIC ) );
        if ( $ids === [] ) {
            return [];
        }

        /** @var array<int,float> $sums */
        $sums = array_fill_keys( $ids, 0.0 );

        $chunk = (int) apply_filters( 'loc_odoo_variant_stock_chunk', 80 );
        if ( $chunk < 1 ) {
            $chunk = 80;
        }
        $read_chunk = (int) apply_filters( 'loc_odoo_variant_read_chunk', 200 );
        if ( $read_chunk < 1 ) {
            $read_chunk = 200;
        }

        for ( $i = 0, $n = count( $ids ); $i < $n; $i += $chunk ) {
            $slice = array_slice( $ids, $i, $chunk );
            $pids  = self::search(
                'product.product',
                [ [ 'product_tmpl_id', 'in', $slice ] ],
                [ 'limit' => 10000, 'order' => 'id asc' ]
            );
            if ( ! is_array( $pids ) || $pids === [] ) {
                self::log( 'inventory_pull', 0, 0, 'error', 'product.product search returned empty for template ids: ' . implode( ',', $slice ) );
                continue;
            }

            // ── Primary: product.product qty_available / free_qty ─────────────
            $read_fields = apply_filters(
                'loc_odoo_variant_stock_read_fields',
                [ 'product_tmpl_id', 'qty_available', 'free_qty' ]
            );
            $primary_filled = false;

            for ( $j = 0, $pn = count( $pids ); $j < $pn; $j += $read_chunk ) {
                $id_chunk = array_slice( $pids, $j, $read_chunk );
                $variants = self::read( 'product.product', $id_chunk, $read_fields );
                if ( ! is_array( $variants ) ) {
                    continue;
                }
                foreach ( $variants as $v ) {
                    if ( ! is_array( $v ) ) {
                        continue;
                    }
                    $tid = self::many2one_to_int( $v['product_tmpl_id'] ?? null );
                    if ( $tid > 0 && array_key_exists( $tid, $sums ) ) {
                        $qty = self::variant_qty_from_odoo_row( $v );
                        $sums[ $tid ] += $qty;
                        if ( $qty > 0 ) {
                            $primary_filled = true;
                        }
                    }
                }
            }

            // ── Fallback: stock.quant when product.product returns all zeros ───
            // Odoo 17+ Online sometimes returns qty_available=0 via JSON-2
            // without a warehouse/location context; stock.quant is the source of truth.
            $all_zero = true;
            foreach ( $slice as $tid ) {
                if ( ( $sums[ $tid ] ?? 0.0 ) > 0 ) {
                    $all_zero = false;
                    break;
                }
            }

            if ( $all_zero && apply_filters( 'loc_odoo_fallback_to_stock_quant', true ) ) {
                $quant_sums = self::sum_qty_from_stock_quant( $pids, $sums, $read_chunk );
                foreach ( $quant_sums as $tid => $qty ) {
                    if ( $qty > 0 ) {
                        $sums[ $tid ] = $qty;
                    }
                }
            }
        }

        return $sums;
    }

    /**
     * Read on-hand quantities from stock.quant (internal locations) for given product.product ids.
     * Used as fallback when product.product.qty_available returns 0 without a location context.
     *
     * @param int[]              $variant_ids   product.product ids to query.
     * @param array<int,float>   $tmpl_sums     Template id → current sum (used to resolve variant → template).
     * @param int                $read_chunk    Ids per read() call.
     * @return array<int,float>  template_id => qty_on_hand summed from stock.quant.
     */
    private static function sum_qty_from_stock_quant( array $variant_ids, array $tmpl_sums, int $read_chunk ): array {
        $template_ids = array_keys( $tmpl_sums );
        $result       = array_fill_keys( $template_ids, 0.0 );

        // Build variant → template map
        $variant_to_tmpl = [];
        for ( $j = 0, $pn = count( $variant_ids ); $j < $pn; $j += $read_chunk ) {
            $chunk_ids = array_slice( $variant_ids, $j, $read_chunk );
            $rows      = self::read( 'product.product', $chunk_ids, [ 'product_tmpl_id' ] );
            if ( ! is_array( $rows ) ) {
                continue;
            }
            foreach ( $rows as $r ) {
                if ( ! is_array( $r ) || ! isset( $r['id'] ) ) {
                    continue;
                }
                $tid = self::many2one_to_int( $r['product_tmpl_id'] ?? null );
                if ( $tid > 0 ) {
                    $variant_to_tmpl[ (int) $r['id'] ] = $tid;
                }
            }
        }

        // Read stock.quant records for these variants in internal locations
        $quants = self::search_read(
            'stock.quant',
            [
                [ 'product_id', 'in', $variant_ids ],
                [ 'location_id.usage', '=', 'internal' ],
            ],
            [ 'product_id', 'quantity', 'reserved_quantity' ],
            [ 'limit' => 100000 ]
        );
        if ( ! is_array( $quants ) ) {
            self::log( 'inventory_pull', 0, 0, 'error', 'stock.quant fallback read failed.' );
            return $result;
        }

        foreach ( $quants as $q ) {
            if ( ! is_array( $q ) ) {
                continue;
            }
            $vid  = self::many2one_to_int( $q['product_id'] ?? null );
            $tid  = $variant_to_tmpl[ $vid ] ?? 0;
            if ( $tid <= 0 || ! array_key_exists( $tid, $result ) ) {
                continue;
            }
            $qty = max( 0.0, (float) ( $q['quantity'] ?? 0 ) - (float) ( $q['reserved_quantity'] ?? 0 ) );
            $result[ $tid ] += $qty;
        }

        if ( apply_filters( 'loc_odoo_debug_log_all_requests', false ) ) {
            foreach ( $result as $tid => $qty ) {
                self::log( 'inventory_pull', 0, $tid, 'ok', "stock.quant fallback qty={$qty}" );
            }
        }

        return $result;
    }

    /**
     * Prefer qty_available; some Odoo / API stacks omit it and expose free_qty instead.
     *
     * @param array<string,mixed> $row product.product read row.
     */
    private static function variant_qty_from_odoo_row( array $row ): float {
        $raw = $row['qty_available'] ?? null;
        if ( ! is_numeric( $raw ) ) {
            $raw = $row['free_qty'] ?? null;
        }
        if ( ! is_numeric( $raw ) ) {
            return 0.0;
        }
        return (float) $raw;
    }

    /**
     * @param mixed $val Many2one value: id or [ id, display_name ].
     */
    private static function many2one_to_int( mixed $val ): int {
        if ( is_int( $val ) || is_float( $val ) ) {
            return (int) $val;
        }
        if ( is_array( $val ) && array_key_exists( 0, $val ) && is_numeric( $val[0] ) ) {
            return (int) $val[0];
        }
        return 0;
    }

    // ── JSON-2 transport (Odoo 19+) ──────────────────────────────────────────

    private static function json2_request( string $model, string $method, array $body ): mixed {
        $key = self::password();
        if ( $key === '' ) {
            self::log( 'json2', 0, 0, 'error', 'Missing API key (password field).' );
            return false;
        }

        $base = self::url();
        $url  = $base . '/json/2/' . rawurlencode( $model ) . '/' . rawurlencode( $method );

        $headers = [
            'Content-Type'  => 'application/json; charset=utf-8',
            'Authorization' => 'bearer ' . $key,
        ];
        $db = self::db();
        if ( $db !== '' ) {
            $headers['X-Odoo-Database'] = $db;
        }
        $ua_ver = defined( 'LOC_VERSION' ) ? LOC_VERSION : '1.0.0';
        $headers['User-Agent'] = 'LIMO-Odoo-Connector/' . $ua_ver . '; ' . home_url( '/' );

        $response = wp_remote_post(
            $url,
            [
                'headers'     => $headers,
                'body'        => wp_json_encode( $body ),
                'timeout'     => 60,
                'data_format' => 'body',
            ]
        );

        if ( is_wp_error( $response ) ) {
            self::log( 'http', 0, 0, 'error', $response->get_error_message() );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        if ( $code < 200 || $code >= 300 ) {
            $msg = is_array( $data ) && isset( $data['message'] )
                ? (string) $data['message']
                : $raw;
            self::log( 'json2', 0, 0, 'error', 'HTTP ' . $code . ': ' . self::truncate( $msg, 500 ) );
            return false;
        }

        return $data;
    }

    // ── Legacy JSON-RPC (/jsonrpc) ───────────────────────────────────────────

    private static function legacy_execute( string $model, string $method, array $args = [], array $kwargs = [] ): mixed {
        $uid = self::authenticate();
        if ( $uid === false ) {
            return false;
        }
        return self::legacy_jsonrpc(
            self::url() . '/jsonrpc',
            'object',
            'execute_kw',
            [ self::db(), $uid, self::password(), $model, $method, $args, $kwargs ]
        );
    }

    private static function legacy_jsonrpc( string $url, string $service, string $method, array $params ): mixed {
        $payload = wp_json_encode( [
            'jsonrpc' => '2.0',
            'method'  => 'call',
            'params'  => [
                'service' => $service,
                'method'  => $method,
                'args'    => $params,
            ],
            'id'      => 1,
        ] );

        $ua_ver = defined( 'LOC_VERSION' ) ? LOC_VERSION : '1.0.0';
        $response = wp_remote_post(
            $url,
            [
                'headers'     => [
                    'Content-Type' => 'application/json',
                    'User-Agent'   => 'LIMO-Odoo-Connector/' . $ua_ver . '; ' . home_url( '/' ),
                ],
                'body'        => $payload,
                'timeout'     => 60,
                'data_format' => 'body',
            ]
        );

        if ( is_wp_error( $response ) ) {
            self::log( 'http', 0, 0, 'error', $response->get_error_message() );
            return false;
        }

        $parsed = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset( $parsed['error'] ) ) {
            $msg = $parsed['error']['data']['message'] ?? wp_json_encode( $parsed['error'] );
            self::log( 'rpc', 0, 0, 'error', self::truncate( (string) $msg, 500 ) );
            return false;
        }

        return $parsed['result'] ?? false;
    }

    /**
     * Odoo normally returns a list of dicts. JSON-2 may rarely return one dict; JSON must not be iterated as key/value rows.
     *
     * @param mixed $data Decoded JSON body.
     * @return array<int,array<string,mixed>>|false
     */
    /**
     * search() / search_read() / read() — Odoo JSON-2 may return one dict for a single row.
     *
     * @param mixed $data Decoded JSON.
     * @return array<int,array<string,mixed>>|false
     */
    private static function normalize_search_read_rows( mixed $data ): array|false {
        if ( $data === false || $data === null ) {
            return false;
        }
        if ( ! is_array( $data ) ) {
            return false;
        }
        if ( $data === [] ) {
            return [];
        }
        if ( function_exists( 'array_is_list' ) && array_is_list( $data ) ) {
            if ( isset( $data[0] ) && is_array( $data[0] ) && array_key_exists( 'id', $data[0] ) ) {
                return $data;
            }
            return [];
        }
        $keys   = array_keys( $data );
        $is_seq = $keys === range( 0, count( $data ) - 1 );
        if ( $is_seq && isset( $data[0] ) && is_array( $data[0] ) && array_key_exists( 'id', $data[0] ) ) {
            return $data;
        }
        if ( isset( $data['id'] ) && is_scalar( $data['id'] ) ) {
            return [ $data ];
        }
        return false;
    }

    /**
     * search() returns a list of integer ids; JSON-2 may return a single id as number.
     *
     * @return int[]|false
     */
    private static function normalize_id_list_result( mixed $data ): array|false {
        if ( $data === false || $data === null ) {
            return false;
        }
        if ( is_int( $data ) || is_float( $data ) ) {
            $i = (int) $data;
            return $i > 0 ? [ $i ] : [];
        }
        if ( is_string( $data ) && ctype_digit( $data ) ) {
            $i = (int) $data;
            return $i > 0 ? [ $i ] : [];
        }
        if ( ! is_array( $data ) ) {
            return false;
        }
        if ( $data === [] ) {
            return [];
        }
        if ( function_exists( 'array_is_list' ) && array_is_list( $data ) ) {
            $out = [];
            foreach ( $data as $x ) {
                $out[] = (int) $x;
            }
            return $out;
        }
        $keys   = array_keys( $data );
        $is_seq = $keys === range( 0, count( $data ) - 1 );
        if ( $is_seq ) {
            $out = [];
            foreach ( $data as $x ) {
                $out[] = (int) $x;
            }
            return $out;
        }
        return false;
    }

    private static function normalize_create_result( mixed $r ): int|false {
        if ( is_int( $r ) && $r > 0 ) {
            return $r;
        }
        if ( is_array( $r ) && isset( $r[0] ) && is_int( $r[0] ) ) {
            return $r[0];
        }
        return false;
    }

    public static function log( string $type, int $obj_id, int $odoo_id, string $status, string $msg = '' ): void {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'loc_sync_log',
            [
                'sync_type' => $type,
                'object_id' => $obj_id,
                'odoo_id'   => $odoo_id,
                'status'    => $status,
                'message'   => self::truncate( $msg, 2000 ),
            ],
            [ '%s', '%d', '%d', '%s', '%s' ]
        );
    }

    private static function truncate( string $str, int $len ): string {
        if ( function_exists( 'mb_substr' ) ) {
            return mb_substr( $str, 0, $len );
        }
        return substr( $str, 0, $len );
    }
}
